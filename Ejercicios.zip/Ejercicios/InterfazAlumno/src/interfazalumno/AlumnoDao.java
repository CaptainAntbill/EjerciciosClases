package interfazalumno;


import interfazalumno.Alumno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Anthony Mejía
 */
public class AlumnoDao {
    
    public static List<Alumno> getAll() throws SQLException {
        List<Alumno> listaAlumno;
        listaAlumno = new ArrayList<>();
        Connection con = Conector.getConexion();
        String sql = "select * from alumno";
        try(PreparedStatement stm = con.prepareStatement(sql)){
            ResultSet resultado = stm.executeQuery();
            
            while(resultado.next()){
                listaAlumno.add(new Alumno(
                    resultado.getString("codigo"),
                    resultado.getString("nombre")
                ));       
            }
            
            return listaAlumno;
        } catch (SQLException e){
            return null;
        }   finally {
            con.close();
            
        }        
    }
    
}
