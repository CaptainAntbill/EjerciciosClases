package interfazalumno;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 *
 * @author Anthony Mejía
 */
public class Conector {

    private static Connection con;
    private static String stringConexion;
    private static boolean connected  = false;
    
    public static Connection getConexion() throws SQLException {
        stringConexion = "jdbc:mysql://165.227.25.59:3306/control_notas";
        con = DriverManager.getConnection(stringConexion, "conexion", "12345");
        connected = true;
        return con;
    }
    public static void close() throws SQLException{
      if(connected ==true) {
          con.close();
      }  
    }
}
