package paquetedeprueba;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Conexion {
    
    public static void main(String args[]) throws SQLException {
        Connection con;
        String stringConexion = "jdbc:mysql://165.227.25.59:3306/control_notas";
        con = DriverManager.getConnection(stringConexion, "conexion","12345");
        
            
    try (PreparedStatement stmt = con.prepareStatement("SELECT * FROM alumno")){
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next())
                System.out.println(rs.getString("codigo") + "\t\t" +
                                   rs.getString("nombre")+ "\n"
                );        
            }   
            
            }
}
        
                